// speakerEmojis.js
export default {
  You: "🧕",  
  Friend: "👬",
  Girl: "👧",
  Boy: "👦",
  Teacher: "👩‍🏫",
  Parent: "👨‍👩‍👧",
};
